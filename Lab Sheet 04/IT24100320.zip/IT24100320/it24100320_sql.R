# Set working directory (replace with your actual path)
setwd("C:\\Users\\IT24100320\\Desktop\\IT24100320")

# Import the dataset
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")
print(branch_data)

str(branch_data)
summary(branch_data)

boxplot(branch_data$Sales_X1, main = "Boxplot of sales", ylab = "sales")

five_num_summary <- fivenum(branch_data$Advertising_X2)
iqr_advertising <- IQR(branch_data$Advertising_X2)
print(five_num_summary)
print(iqr_advertising)

get.outliers <- function(z){
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  
  ub <- q3 + 1.5 * iqr
  lb <- q1 - 1.5 * iqr
  
  print(paste("Upper Bound =", ub))
  print(paste("Lower Bound =", lb))
  print(paste("Outliers:", paste(sort(z[z < lb | z > ub]), collapse = ", ")))
}

# Check for outliers in Years variable (X3)
get.outliers(X3)











